package nl.rabobank.statement.util;

public class IncorrectBalanceException extends BankingException {

}
