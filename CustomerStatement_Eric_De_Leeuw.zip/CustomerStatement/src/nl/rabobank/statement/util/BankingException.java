package nl.rabobank.statement.util;

public class BankingException extends Exception {

}
