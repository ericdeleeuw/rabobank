package nl.rabobank.statement.util;

public class DuplicateReferenceException extends BankingException {

}
