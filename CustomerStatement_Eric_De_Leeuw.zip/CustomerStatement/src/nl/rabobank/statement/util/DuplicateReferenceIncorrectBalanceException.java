package nl.rabobank.statement.util;

public class DuplicateReferenceIncorrectBalanceException extends BankingException {

}
