package nl.rabobank.statement;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Eric de Leeuw
 * This class holds the response of the webservice
 */
public class CustomerStatementResponse {

	String result;
	List<ErrorRecord> errorRecords = new ArrayList<ErrorRecord>();


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}


	public List<ErrorRecord> getErrorRecords() {
		return errorRecords;
	}



	public void setErrorRecords(List<ErrorRecord> errorRecords) {
		this.errorRecords = errorRecords;
	}

	public void addErrorRecord(String reference, String accountnumber) {
		errorRecords.add(new ErrorRecord(reference, accountnumber));
	}


	public class ErrorRecord {
		
		String reference;
		String accountNumber;
		
		public ErrorRecord(String reference, String accountNumber) {
			this.reference = reference;
			this.accountNumber = accountNumber;
		}
		
		public String getReference() {
			return reference;
		}
		
		public void setReference(String reference) {
			this.reference = reference;
		}
		
		public String getAccountNumber() {
			return accountNumber;
		}
		
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		
		
		
	}
	
	
}
