package nl.rabobank.statement;

import nl.rabobank.statement.model.Bank;
import nl.rabobank.statement.util.BankingException;

/**
 * 
 * @author Eric de Leeuw
 *
 */
public class CustomerStatementController {

	// For simplicity holding the bank data as a static instance. Better would be a
	// database of course.
	private static Bank bank = new Bank();

	/**
	 * 
	 * @param transactionReference
	 * @param accountNumber
	 * @param startBalance
	 * @param endBalance
	 * @param mutation
	 * @param description
	 * @return
	 * @throws BankingException
	 */
	public String processTransactionStatement(String transactionReference, String accountNumber, float startBalance,
			float endBalance, String mutation, String description) throws BankingException {

		// call the bank to process the incoming request
		return bank.processTransactionStatement(transactionReference, accountNumber, startBalance, endBalance, mutation,
				description);

	}

}
