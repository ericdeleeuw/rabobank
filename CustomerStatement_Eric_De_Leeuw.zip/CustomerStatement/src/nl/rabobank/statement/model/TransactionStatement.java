package nl.rabobank.statement.model;

/**
 * 
 * @author Eric de Leeuw
 *
 */
public class TransactionStatement {

	private String transactionReference;
	private float startBalance;
	private float endBalance;
	private String mutationType;
	private String description;
	
	
	public String getTransactionReference() {
		return transactionReference;
	}
	public void setTransactionReference(String transactionReference) {
		this.transactionReference = transactionReference;
	}
	public float getStartBalance() {
		return startBalance;
	}
	public void setStartBalance(float startBalance) {
		this.startBalance = startBalance;
	}
	public float getEndBalance() {
		return endBalance;
	}
	public void setEndBalance(float endBalance) {
		this.endBalance = endBalance;
	}
	public String getMutationType() {
		return mutationType;
	}
	public void setMutationType(String mutationType) {
		this.mutationType = mutationType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
