package nl.rabobank.statement.model;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import nl.rabobank.statement.CustomerStatementService;
import nl.rabobank.statement.util.BankingException;

/**
 * 
 * @author Eric de Leeuw
 *
 */
public class Bank {

	private Map<String, Account> accounts = new HashMap<String, Account>();
	
	public final static String STATUS_CODE_SUCCESFUL = "SUCCESSFUL";
	public final static String STATUS_CODE_DUPLICATE_REFERENCE = "DUPLICATE_REFERENCE";
	public final static String STATUS_CODE_INCORRECT_END_BALANCE = "INCORRECT_END_BALANCE";
	public final static String STATUS_CODE_DUPLICATE_REFERENCE_INCORRECT_END_BALANCE = "DUPLICATE_REFERENCE_INCORRECT_END_BALANCE";	
	public final static String STATUS_CODE_BAD_REQUEST = "BAD_REQUEST";		
	public final static String STATUS_CODE_INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";		
	
	private static final Logger LOGGER = Logger.getLogger(CustomerStatementService.class.getName());

	public Map<String, Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<String, Account> accounts) {
		this.accounts = accounts;
	}
	
	/**
	 * 
	 * @param accountNumber
	 * @return
	 */
	private Account addAccount(String accountNumber) {

		Account acc = new Account();
		acc.setAccountNumber(accountNumber);
		accounts.put(accountNumber, acc);
		
		LOGGER.log(Level.INFO,"Added new account: " + accountNumber);
		return acc;


	}
	
	/**
	 * Method used for finding an existing Account. if not found a new on is created
	 * @param accountNumber
	 * @return Account
	 */
	public Account findAccountByAccountNumber(String accountNumber){
		
		Account acc = accounts.get(accountNumber);
		LOGGER.log(Level.INFO,"Trying to find account: " + accountNumber);
		if(acc == null) {
			acc = addAccount(accountNumber);
		}	
		LOGGER.log(Level.INFO,"available accounts: " + accounts);	
		return acc;
	}

	/**
	 * Method that holds the logic for processing the transaction that comes form the service (controller)
	 * @param transactionReference
	 * @param accountNumber
	 * @param startBalance
	 * @param endBalance
	 * @param mutation
	 * @param description
	 * @return String containing a status message
	 * @throws BankingException
	 */
	public String processTransactionStatement(String transactionReference, String accountNumber, float startBalance,
			float endBalance, String mutation, String description) throws BankingException{
		
		Account account = findAccountByAccountNumber(accountNumber);
		LOGGER.log(Level.INFO,"Process transaction reference: " + transactionReference);
		String message = account.addTransactionStatement(transactionReference, startBalance,
			endBalance, mutation, description);

		LOGGER.log(Level.INFO,"Message = " + message);
		return message;
		
	}
}
