package nl.rabobank.statement.model;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import nl.rabobank.statement.CustomerStatementService;
import nl.rabobank.statement.util.BankingException;
import nl.rabobank.statement.util.DuplicateReferenceException;
import nl.rabobank.statement.util.DuplicateReferenceIncorrectBalanceException;
import nl.rabobank.statement.util.IncorrectBalanceException;

/**
 * 
 * @author Eric de Leeuw
 *
 */
public class Account {


	private String accountNumber;
	private float balance = 0;
	private Map<String, TransactionStatement> transactionStatements = new HashMap<String, TransactionStatement>();

	private static final Logger LOGGER = Logger.getLogger(CustomerStatementService.class.getName());

	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	public void addTransactionStatement(TransactionStatement transactionStatement) {
		transactionStatements.put(transactionStatement.getTransactionReference(), transactionStatement);
	}
	
	/**
	 * Checks the balance
	 * @param startBalance
	 * @param endBalance
	 * @param mutation
	 * @return
	 * @throws BankingException
	 */
	private boolean checkBalance(float startBalance, float endBalance, String mutation) throws BankingException {
		LOGGER.log(Level.INFO,"Checking balance...");
		if(!"plus".equals(mutation) && !"minus".equals(mutation)) {
			LOGGER.log(Level.WARNING," Mutation not + or - :" + mutation);
			throw new BankingException();
		}
		if("plus".equals(mutation)) {
			if(endBalance < startBalance) {
				LOGGER.log(Level.WARNING,"Mutation = +, but endbalance < startbalance...");
				return false;
			}
		} else if("minus".equals(mutation)) {
			if(endBalance > startBalance) {
				
				LOGGER.log(Level.WARNING,"Mutation = -, but endbalance > startbalance...");
				return false;
			}
		} 
		LOGGER.log(Level.INFO,"Balance is correct");
		return true;
	}
	
	/**
	 * Validates the transaction statement
	 * @param transactionReference
	 * @param startBalance
	 * @param endBalance
	 * @param mutation
	 * @throws BankingException
	 */
	private void validateTransactionStatement(String transactionReference, float startBalance, float endBalance,
			String mutation) throws BankingException{
		
		TransactionStatement trans = transactionStatements.get(transactionReference);
		LOGGER.log(Level.INFO,"Trying to find transaction statement: " + transactionReference);
		if(trans != null) {
			LOGGER.log(Level.INFO,"Transaction reference already extists.... ");
			if(!checkBalance(startBalance, endBalance, mutation)) {
				throw new DuplicateReferenceIncorrectBalanceException();
			}
			throw new DuplicateReferenceException();
		} else {
			if(!checkBalance(startBalance, endBalance, mutation)) {
				throw new IncorrectBalanceException();
			}
			trans = new TransactionStatement();
			trans.setTransactionReference(transactionReference);
			addTransactionStatement(trans);
		}	

	}
	
	/**
	 * Adds the transactionStatement and return the status/error code
	 * @param transactionReference
	 * @param startBalance
	 * @param endBalance
	 * @param mutation
	 * @param description
	 * @return
	 */
	public String addTransactionStatement(String transactionReference, float startBalance, float endBalance,
			String mutation, String description) {
		
		try {
			validateTransactionStatement(transactionReference, startBalance, endBalance, mutation);
			LOGGER.log(Level.INFO,"available transactions: " + transactionStatements);	
			
		} catch	(DuplicateReferenceException dr) {
			
			return Bank.STATUS_CODE_DUPLICATE_REFERENCE;	
			
		} catch	(DuplicateReferenceIncorrectBalanceException drib) {
			
			return Bank.STATUS_CODE_DUPLICATE_REFERENCE_INCORRECT_END_BALANCE;
			
		} catch (IncorrectBalanceException e) {
			
			return Bank.STATUS_CODE_INCORRECT_END_BALANCE;
			
		} catch (BankingException e) {
			
			return Bank.STATUS_CODE_BAD_REQUEST;
		}
		return Bank.STATUS_CODE_SUCCESFUL;
	}
	
	
}
