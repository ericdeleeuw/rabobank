package nl.rabobank.statement;



import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import nl.rabobank.statement.model.Bank;
import nl.rabobank.statement.util.BankingException;

/**
 * 
 * @author Eric de Leeuw
 *
 */
@Path("/statement")
public class CustomerStatementService {

	// Controller class for the statements service
	private static CustomerStatementController controller = new CustomerStatementController();
    
	private static final Logger LOGGER = Logger.getLogger(CustomerStatementService.class.getName());



	@PUT
	@Path("/add-statement")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addCustomerStatement(@QueryParam("transactionReference") String transactionReference,
			@QueryParam("accountNumber") String accountNumber, @QueryParam("startBalance") float startBalance,
			@QueryParam("mutation") String mutation, @QueryParam("description") String description,
			@QueryParam("endBalance") float endBalance) {


		LOGGER.log(Level.INFO, "Received values: transactionReference: " + transactionReference + ", accountNumber: "
				+ accountNumber + ", mutation: " + mutation);

		CustomerStatementResponse response = new CustomerStatementResponse();
		
		try {
			// call the controller
			String message = controller.processTransactionStatement(transactionReference, accountNumber, startBalance,
					endBalance, mutation, description);

			response.setResult(message);
			
			if (Bank.STATUS_CODE_DUPLICATE_REFERENCE.equals(message)) {

				response.addErrorRecord(transactionReference, accountNumber);


			} else if (Bank.STATUS_CODE_INCORRECT_END_BALANCE.equals(message)) {

				response.addErrorRecord("" + endBalance, accountNumber);


			} else if (Bank.STATUS_CODE_DUPLICATE_REFERENCE_INCORRECT_END_BALANCE.equals(message)) {

				response.addErrorRecord(transactionReference, accountNumber);
				response.addErrorRecord("" + endBalance, accountNumber);


			} else if (Bank.STATUS_CODE_BAD_REQUEST.equals(message)) {

				//Return a 400 error
				GenericEntity<CustomerStatementResponse> entity = new GenericEntity<CustomerStatementResponse>(response, CustomerStatementResponse.class);
				return Response.status(400).entity(entity).build();
			}

		} catch (BankingException be) {

			// Return a 500 error
			GenericEntity<CustomerStatementResponse> entity = new GenericEntity<CustomerStatementResponse>(response, CustomerStatementResponse.class);
			return Response.status(500).entity(entity).build();
		}
		// Return a 200 status code
		GenericEntity<CustomerStatementResponse> entity = new GenericEntity<CustomerStatementResponse>(response, CustomerStatementResponse.class);
	    return Response.ok().entity(entity).build();

	}
}
