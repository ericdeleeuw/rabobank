package nl.rabobank.statement;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.JerseyClient;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.junit.jupiter.api.Test;

import nl.rabobank.statement.model.Bank;

/**
 * 
 * @author Eric de Leeuw
 * Integration test class
 */
public class StatementWebserviceTestIT {

	

	
	@Test
	public void testIntegrationJSONSucess() {
		

		int max = 10000;
		int min = 1;
		Random randomNum = new Random();
		int tNum = min + randomNum. nextInt(max);

		CustomerStatementResponse resp = callService(""+tNum, "3456", "100",
				"800", "plus", "hallo") ;


		assertEquals(Bank.STATUS_CODE_SUCCESFUL, resp.getResult());

	}

	@Test
	public void testIntegrationJSONIncorrectEndBalance() {

		int max = 10000;
		int min = 1;
		Random randomNum = new Random();
		int tNum = min + randomNum. nextInt(max);


		CustomerStatementResponse resp = callService(""+tNum, "3456", "100",
				"800", "minus", "hallo") ;
		


		assertEquals(Bank.STATUS_CODE_INCORRECT_END_BALANCE, resp.getResult());

	}
	
	@Test
	public void testIntegrationJSONIBadrequest() {

		int max = 10000;
		int min = 1;
		Random randomNum = new Random();
		int tNum = min + randomNum. nextInt(max);
		
		CustomerStatementResponse resp = callService(""+tNum, "3456", "100",
				"800", "blabla", "hallo") ;
		


		assertEquals(Bank.STATUS_CODE_BAD_REQUEST, resp.getResult());

	}	

	private CustomerStatementResponse callService(String transactionReference, String accountNumber, String startBalance,
			String endBalance, String mutation, String description) {
		JerseyClient client = JerseyClientBuilder.createClient();

		WebTarget webTarget = client.target("http://localhost:8080/CustomerStatement-0.0.1-SNAPSHOT/rest/")
				.path("statement").path("add-statement");
		webTarget = webTarget.queryParam("transactionReference", transactionReference);
		webTarget = webTarget.queryParam("accountNumber", accountNumber);
		webTarget = webTarget.queryParam("startBalance", "" + startBalance);
		webTarget = webTarget.queryParam("endBalance", "" + endBalance);
		webTarget = webTarget.queryParam("mutation", mutation);
		webTarget = webTarget.queryParam("description", description);

		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON_TYPE);
		Response response = invocationBuilder.put(Entity.entity("{}", MediaType.APPLICATION_JSON_TYPE));
		System.out.println(response.toString());

		return response.readEntity(CustomerStatementResponse.class);

	}

}
