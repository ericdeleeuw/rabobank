package nl.rabobank.statement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

import nl.rabobank.statement.model.Bank;
import nl.rabobank.statement.util.BankingException;

/**
 * Testclass for the business logic 
 * @author Eric de Leeuw
 *
 */
class StatementWebserviceTest {


	/**
	 * Test sucess
	 */
	@Test
	void testSuccess() {
		Bank bank = new Bank();
		try {
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "plus", "test omschrijving");
			assertEquals(Bank.STATUS_CODE_SUCCESFUL, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}
	
	/**
	 * Test invalid mutation
	 */
	@Test
	void testMinusTransaction() {
		Bank bank = new Bank();
		try {
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					60, "minus", "test omschrijving");
			assertEquals(Bank.STATUS_CODE_SUCCESFUL, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}
	
	/**
	 * Test duplicate reference, with new account
	 */
	@Test
	void testSameReferenceNewAccount() {
		Bank bank = new Bank();
		try {
			// call once
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "plus", "test omschrijving");
			//call twice
			message = bank.processTransactionStatement("1234", "987654321", 100,
					120, "plus", "test omschrijving");			

			assertEquals(Bank.STATUS_CODE_SUCCESFUL, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}
	
	
	/**
	 * Test duplicate reference
	 */
	@Test
	void testDuplicateReference() {
		Bank bank = new Bank();
		try {
			// call once
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "plus", "test omschrijving");
			//call twice
			message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "plus", "test omschrijving");			
			assertEquals(Bank.STATUS_CODE_DUPLICATE_REFERENCE, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}	
	
	/**
	 * Test incorrect end balance
	 */
	@Test
	void testIncorrectEndBalance() {
		Bank bank = new Bank();
		try {
			// call once
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					80, "plus", "test omschrijving");
		
			assertEquals(Bank.STATUS_CODE_INCORRECT_END_BALANCE, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}	
	
	/**
	 * Test duplicate reference and incorrect end balance
	 */
	@Test
	void testDuplicateReferenceAndIncorrectBalance() {
		Bank bank = new Bank();
		try {
			// call once
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "plus", "test omschrijving");
			//call twice
			message = bank.processTransactionStatement("1234", "123456789", 100,
					180, "minus", "test omschrijving");			
			assertEquals(Bank.STATUS_CODE_DUPLICATE_REFERENCE_INCORRECT_END_BALANCE, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}
	
	/**
	 * Test for invalid data, resulting in a bad request
	 */
	@Test
	void testInvalidData() {
		Bank bank = new Bank();
		try {
			// call once
			String message = bank.processTransactionStatement("1234", "123456789", 100,
					120, "Troep", "test omschrijving");
			
			assertEquals(Bank.STATUS_CODE_BAD_REQUEST, message);

		} catch (BankingException e) {
			fail("Something went wrong");
			e.printStackTrace();
		}

	}
	

}
